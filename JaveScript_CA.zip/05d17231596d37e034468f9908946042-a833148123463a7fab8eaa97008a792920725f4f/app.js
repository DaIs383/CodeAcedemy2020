// forcasr temp in Kelvin
const kelvin = 0;
//conversion to celsius
var celsius = kelvin - 273;
// celius to far
let fahrenheit = celsius*(9/5) + 32;
//round far down
fahrenheit = Math.floor(fahrenheit);
console.log(`The temperture is ${fahrenheit} degrees Fahrenheit`);
