// varaible for age
var myAge = 2;
// varaible for earlyYears
let earlyYears = 2;
earlyYears *= 10.5;
// LaterYears
let laterYears = myAge - 2;
//Dog Years
laterYears *= 4;
console.log(earlyYears);
console.log(laterYears); 
//Age in Dog Years
var myAgeInDogYears = (earlyYears + laterYears);
//Var for name and to lowercase
var myName = 'Mosi';
console.log(myName.toLowerCase());
console.log(`My name is ${myName}. I am ${myAge} in human years which is ${myAgeInDogYears} years in dog years.` );
